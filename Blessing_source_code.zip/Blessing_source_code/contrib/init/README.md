Sample configuration files for:
```
SystemD: blessingd.service
Upstart: blessingd.conf
OpenRC:  blessingd.openrc
         blessingd.openrcconf
CentOS:  blessingd.init
macOS:    org.blessing.blessingd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
